using UnityEngine;

// Este componente sirve para "marcar" cuál es el Board (la mesa).
// Así cualquier carta puede encontrarlo y re-parentarse acá al arrastrar.
public class BoardRoot : MonoBehaviour
{
    // Guardamos una referencia global al Board activo (singleton simple).
    // El patrón singleton permite que CUALQUIER otro script acceda a BoardRoot.Instance.
    public static BoardRoot Instance { get; private set; }

    // Awake() se llama automáticamente cuando la escena carga, ANTES de Start().
    private void Awake()
    {
        // Se asigna a sí mismo como la instancia única.
        // Cuando arranca la escena, este Board queda como el Board principal.
        Instance = this;
    }
}