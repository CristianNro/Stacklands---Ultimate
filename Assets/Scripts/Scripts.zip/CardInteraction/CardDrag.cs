using UnityEngine;
using UnityEngine.EventSystems;

// Este script permite arrastrar una carta.
// Si la carta pertenece a un stack:
// - si es la primera carta del stack, arrastra todo el stack
// - si está en el medio, parte el stack y arrastra el substack desde esa carta hacia abajo
public class CardDrag : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    private RectTransform rectTransform;
    private Canvas canvas;
    private CanvasGroup canvasGroup;

    // Referencia a la carta visual
    private CardView cardView;

    // Qué transform estamos arrastrando realmente:
    // puede ser la carta sola o puede ser un CardStack
    private RectTransform draggedRectTransform;

    // Stack actual que estamos arrastrando, si existe
    private CardStack draggedStack;

    private void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        canvas = GetComponentInParent<Canvas>();
        cardView = GetComponent<CardView>();

        canvasGroup = GetComponent<CanvasGroup>();
        if (canvasGroup == null)
            canvasGroup = gameObject.AddComponent<CanvasGroup>();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        // Por defecto pensamos que arrastramos esta carta suelta
        draggedRectTransform = rectTransform;
        draggedStack = null;

        // Buscamos si esta carta pertenece a un stack
        CardStack parentStack = GetComponentInParent<CardStack>();

        if (parentStack != null)
        {
            int index = parentStack.GetCardIndex(cardView);

            // Si está en un stack:
            // - si index == 0, arrastramos todo ese stack
            // - si index > 0, partimos el stack y arrastramos el substack nuevo
            draggedStack = parentStack.SplitFrom(cardView);

            // Ahora lo que se arrastra es el RectTransform del stack
            draggedRectTransform = draggedStack.GetComponent<RectTransform>();

            // Lo traemos al frente visualmente
            draggedStack.transform.SetAsLastSibling();
        }
        else
        {
            // Si no pertenece a stack, arrastramos la carta sola
            transform.SetAsLastSibling();
        }

        // La carta que agarramos deja de bloquear raycasts mientras arrastramos
        canvasGroup.blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (draggedRectTransform == null) return;

        // Movemos lo que se esté arrastrando:
        // una carta sola o un stack entero
        draggedRectTransform.anchoredPosition += eventData.delta / canvas.scaleFactor;
    }

    private Vector2 GetLocalPointInBoard(PointerEventData eventData)
    {
        RectTransform boardRect = BoardRoot.Instance.GetComponent<RectTransform>();
        Vector2 localPoint;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            boardRect,
            eventData.position,
            eventData.pressEventCamera,
            out localPoint
        );

        return localPoint;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        canvasGroup.blocksRaycasts = true;

        GameObject hitObject = eventData.pointerCurrentRaycast.gameObject;

        if (hitObject == null)
            return;

        // Buscamos si soltamos sobre una carta
        CardView targetCard = hitObject.GetComponentInParent<CardView>();

        if (targetCard == null){
                if (draggedStack != null && draggedStack.HasOnlyOneCard())
                {
                    // Si soltamos una sola carta en el board vacío, se borra el stack y la carta queda suelta en el board
                    RectTransform rt = GetComponent<RectTransform>();
                    rt.SetParent(BoardRoot.Instance.transform, false);
                    rt.anchoredPosition = GetLocalPointInBoard(eventData);
                    Destroy(draggedStack.gameObject);
                }
            return;
        }

        if (targetCard.gameObject == this.gameObject)
            return;

        // Si estamos arrastrando un stack
        if (draggedStack != null)
        {
            // Revisamos si la carta target ya pertenece a otro stack
            CardStack targetStack = targetCard.GetComponentInParent<CardStack>();

            if (targetStack != null && targetStack != draggedStack)
            {
                // Fusionamos los dos stacks:
                // agregamos todas las cartas del stack arrastrado al target
                foreach (var card in draggedStack.Cards)
                {
                    targetStack.AddCard((CardView)card);
                }

                // Destruimos el stack arrastrado vacío
                Destroy(draggedStack.gameObject);
            }
            else if (targetStack == null)
            {
                // La carta target estaba sola: creamos un stack nuevo
                CardStack newStack = CardStackFactory.CreateStack(targetCard, cardView);

                // Si el stack arrastrado tenía más cartas que solo esta carta,
                // las agregamos también
                if (draggedStack.Cards.Count > 1)
                {
                    for (int i = 1; i < draggedStack.Cards.Count; i++)
                    {
                        newStack.AddCard((CardView)draggedStack.Cards[i]);
                    }
                }

                Destroy(draggedStack.gameObject);
            }

            return;
        }

        // Si arrastrábamos una carta suelta:
        CardStack existingTargetStack = targetCard.GetComponentInParent<CardStack>();

        if (existingTargetStack != null)
        {
            // Si la target ya está en stack, agregamos esta carta al stack
            existingTargetStack.AddCard(cardView);
        }
        else
        {
            // Si la target está sola, creamos stack nuevo con ambas
            CardStackFactory.CreateStack(targetCard, cardView);
        }
    }
}