using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

// Este componente representa un stack real de cartas.
// Además de ordenar visualmente las cartas,
// ahora también detecta y procesa recetas con tiempo.
public class CardStack : MonoBehaviour
{
    // Lista ordenada de cartas dentro del stack
    [SerializeField] private List<CardView> cards = new List<CardView>();

    // Separación visual entre cartas
    [SerializeField] private Vector2 stackOffset = new Vector2(0f, -28f);

    // ----- UI de progreso de crafting -----

    // Objeto raíz de la barra de progreso
    private GameObject progressBarRoot;

    // Imagen que se va llenando
    private Image progressFillImage;

    // Tiempo total de la receta actual.
    // Lo guardamos para calcular porcentaje de progreso.
    private float totalCraftTime;

    // Receta activa que este stack está procesando
    private RecipeData activeRecipe;

    // Tiempo restante del crafting actual
    private float craftTimer;

    // Indica si el stack está crafteando ahora mismo
    private bool isCrafting = false;

    // Exponemos la lista como solo lectura
    public IReadOnlyList<CardView> Cards => cards;

    // Agrega una carta al stack
    public void AddCard(CardView card)
    {
        if (card == null) return;
        if (cards.Contains(card)) return;

        // La agregamos a la lista
        cards.Add(card);

        // La hacemos hija visual del stack
        card.transform.SetParent(transform, worldPositionStays: false);

        Debug.Log("RefreshLayout ejecutado");

        // Reacomodamos cartas
        RefreshLayout();

        // Cada vez que cambia el stack, revisamos recetas
        CheckRecipe();
    }

    // Agrega varias cartas al stack
    public void AddCards(List<CardView> newCards)
    {
        if (newCards == null) return;

        foreach (CardView card in newCards)
        {
            if (card == null) continue;
            if (cards.Contains(card)) continue;

            cards.Add(card);
            card.transform.SetParent(transform, worldPositionStays: false);
        }

        RefreshLayout();

        // Si cambió el contenido, revisamos recetas
        CheckRecipe();
    }

    // Quita una carta del stack
    public void RemoveCard(CardView card)
    {
        if (card == null) return;
        if (!cards.Contains(card)) return;

        cards.Remove(card);

        // La devolvemos al board/playarea
        RectTransform cardRT = card.GetComponent<RectTransform>();
        RectTransform boardRT = BoardRoot.Instance.GetComponent<RectTransform>();

        Vector2 screenPoint = RectTransformUtility.WorldToScreenPoint(null, cardRT.position);
        Vector2 boardLocalPoint;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            boardRT,
            screenPoint,
            null,
            out boardLocalPoint
        );

        cardRT.SetParent(BoardRoot.Instance.transform, false);
        cardRT.anchoredPosition = boardLocalPoint;


        RefreshLayout();

        // Si cambia el stack, cualquier crafting actual puede dejar de ser válido
        CheckRecipe();
    }

    // Recalcula la posición de todas las cartas del stack
    public void RefreshLayout()
    {
        Vector2 effectiveOffset = stackOffset;

        if (cards.Count > 0 && cards[0] != null)
        {
            CardDropTarget dropTarget = cards[0].GetComponent<CardDropTarget>();
            if (dropTarget != null)
            {
                effectiveOffset = dropTarget.GetStackOffset();
            }
        }

        for (int i = 0; i < cards.Count; i++)
        {
            CardView card = cards[i];
            if (card == null) continue;

            RectTransform rt = card.GetComponent<RectTransform>();

            rt.anchoredPosition = effectiveOffset * i;
            card.transform.SetSiblingIndex(i);
        }
    }


    // Devuelve la posición de una carta dentro del stack
    public int GetCardIndex(CardView card)
    {
        return cards.IndexOf(card);
    }

    // Verifica si una carta pertenece a este stack
    public bool Contains(CardView card)
    {
        return cards.Contains(card);
    }

    // Devuelve la lista de CardData del stack actual
    public List<CardData> GetCardDataList()
    {
        List<CardData> result = new List<CardData>();

        foreach (CardView card in cards)
        {
            if (card != null && card.data != null)
                result.Add(card.data);
        }

        return result;
    }

    // Devuelve la primera carta del stack
    public CardView GetRootCard()
    {
        if (cards.Count == 0) return null;
        return cards[0];
    }

    // Devuelve la posición actual del stack
    public Vector2 GetStackPosition()
    {
        RectTransform rt = GetComponent<RectTransform>();
        return rt.anchoredPosition;
    }

    // Parte el stack a partir de una carta concreta
    public CardStack SplitFrom(CardView card)
    {
        if (card == null) return null;

        int index = cards.IndexOf(card);

        if (index == -1) return null;

        // Si la carta es la primera, ya representa el stack entero
        if (index == 0)
            return this;

        // Creamos un nuevo stack
        GameObject newStackGO = new GameObject("CardStack", typeof(RectTransform));
        RectTransform newStackRT = newStackGO.GetComponent<RectTransform>();
        RectTransform boardRT = BoardRoot.Instance.GetComponent<RectTransform>();
        RectTransform draggedCardRT = card.GetComponent<RectTransform>();

        // Primero obtenemos la posición visual real de la carta en pantalla
        Vector2 screenPoint = RectTransformUtility.WorldToScreenPoint(null, draggedCardRT.position);

        // Después convertimos esa posición a coordenadas locales del board
        Vector2 boardLocalPoint;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            boardRT,
            screenPoint,
            null,
            out boardLocalPoint
        );

        // Recién ahí lo parentamos al board y le damos la posición correcta
        newStackRT.SetParent(BoardRoot.Instance.transform, false);
        newStackRT.anchoredPosition = boardLocalPoint;

        CardStack newStack = newStackGO.AddComponent<CardStack>();

        // Tomamos las cartas desde esa posición hasta el final
        List<CardView> movedCards = new List<CardView>();

        for (int i = index; i < cards.Count; i++)
        {
            movedCards.Add(cards[i]);
        }

        // Las quitamos del stack original
        for (int i = movedCards.Count - 1; i >= 0; i--)
        {
            cards.Remove(movedCards[i]);
        }

        // Las agregamos al nuevo stack
        newStack.AddCards(movedCards);

        // Reacomodamos el stack original
        RefreshLayout();

        // Como cambió el contenido del original, revisamos su receta
        CheckRecipe();

        return newStack;
    }

    // Update se ejecuta cada frame.
    // Lo usamos para avanzar el timer del crafting actual.
    private void Update()
    {
        // Si no está crafteando, no hacemos nada
        if (!isCrafting) return;

        // Restamos tiempo
        craftTimer -= Time.deltaTime;

        // Actualizamos la barra visual cada frame
        UpdateProgressBar();

        // Si llegó a 0 o menos, completamos la receta
        if (craftTimer <= 0f)
        {
            CompleteRecipe();
        }
    }

    // Revisa si el stack actual coincide con alguna receta
    public void CheckRecipe()
    {
        // Cada vez que cambia el stack, cancelamos cualquier crafting anterior
        CancelCrafting();

        // Si no hay cartas, no tiene sentido buscar receta
        if (cards.Count == 0) return;

        // Obtenemos la lista actual de CardData
        List<CardData> stackData = GetCardDataList();

        // Buscamos una receta que coincida
        RecipeData recipe = RecipeDatabase.Instance.FindRecipe(stackData);

        // Si no hay receta, salimos
        if (recipe == null) return;

        // Si sí hay receta, comenzamos el crafting
        StartCrafting(recipe);
    }

        // Inicia el procesamiento de una receta
    private void StartCrafting(RecipeData recipe)
    {
        if (recipe == null) return;

        activeRecipe = recipe;
        craftTimer = Mathf.Max(0.01f, recipe.craftTime);
        totalCraftTime = craftTimer;
        isCrafting = true;

        CreateProgressBar();
        UpdateProgressBar();

        Debug.Log("Comenzó crafting de: " + recipe.result.cardName + " | tiempo: " + craftTimer);
    }

    // Cancela el crafting actual
    private void CancelCrafting()
    {
        activeRecipe = null;
        craftTimer = 0f;
        totalCraftTime = 0f;
        isCrafting = false;

        // Si se cancela, borramos la barra
        DestroyProgressBar();
    }

    // Completa la receta activa
    private void CompleteRecipe()
    {
        // Seguridad: si no hay receta activa, salimos
        if (activeRecipe == null || activeRecipe.result == null)
        {
            CancelCrafting();
            return;
        }

        Debug.Log("Receta completada: " + activeRecipe.result.cardName);

        // Guardamos la posición actual del stack para spawnear el resultado ahí
        Vector2 spawnPos = GetStackPosition();

        // Hacemos una copia de la lista para no modificarla mientras iteramos
        List<CardView> cardsToProcess = new List<CardView>(cards);

        // Procesamos cada carta según su CardInstance / durabilidad
        foreach (CardView card in cardsToProcess)
        {
            if (card == null) continue;

            CardInstance instance = card.GetComponent<CardInstance>();

            // Si tiene instancia y se rompe al consumir un uso, la destruimos
            if (instance != null && instance.ConsumeUseIfNeeded())
            {
                cards.Remove(card);
                Destroy(card.gameObject);
            }
        }

        // Spawneamos la carta resultado
        CardSpawner.Instance.SpawnAnimated(activeRecipe.result, spawnPos);

        // Como esta receta ya terminó, reseteamos estado
        CancelCrafting();

        // Si querés que el stack desaparezca cuando ya no tenga sentido, podés hacerlo acá
        // Por ahora simplemente revisamos si quedó alguna receta nueva posible
        CheckRecipe();
    }

    // Devuelve true si el stack quedó vacío
    public bool IsEmpty()
    {
        return cards.Count == 0;
    }

    // Devuelve true si quedó solo una carta
    public bool HasOnlyOneCard()
    {
        return cards.Count == 1;
    }

    // Crea visualmente una barra de progreso arriba del stack.
    private RectTransform progressFillRect;

    private void CreateProgressBar()
    {
        if (progressBarRoot != null) return;

        progressBarRoot = new GameObject("CraftProgressBar", typeof(RectTransform));
        progressBarRoot.transform.SetParent(transform, false);

        RectTransform rootRT = progressBarRoot.GetComponent<RectTransform>();
        rootRT.anchoredPosition = new Vector2(0f, 65f);
        rootRT.sizeDelta = new Vector2(100f, 12f);
        rootRT.anchorMin = new Vector2(0.5f, 0.5f);
        rootRT.anchorMax = new Vector2(0.5f, 0.5f);
        rootRT.pivot = new Vector2(0.5f, 0.5f);

        // Fondo
        GameObject backgroundGO = new GameObject("Background", typeof(RectTransform), typeof(Image));
        backgroundGO.transform.SetParent(progressBarRoot.transform, false);

        RectTransform bgRT = backgroundGO.GetComponent<RectTransform>();
        bgRT.anchorMin = Vector2.zero;
        bgRT.anchorMax = Vector2.one;
        bgRT.offsetMin = Vector2.zero;
        bgRT.offsetMax = Vector2.zero;

        Image bgImage = backgroundGO.GetComponent<Image>();
        bgImage.color = new Color(0f, 0f, 0f, 0.6f);

        // Fill
        GameObject fillGO = new GameObject("Fill", typeof(RectTransform), typeof(Image));
        fillGO.transform.SetParent(backgroundGO.transform, false);

        progressFillRect = fillGO.GetComponent<RectTransform>();
        progressFillRect.anchorMin = new Vector2(0f, 0f);
        progressFillRect.anchorMax = new Vector2(0f, 1f);
        progressFillRect.pivot = new Vector2(0f, 0.5f);
        progressFillRect.anchoredPosition = Vector2.zero;
        progressFillRect.sizeDelta = new Vector2(0f, 0f);

        progressFillImage = fillGO.GetComponent<Image>();
        progressFillImage.color = new Color(0.2f, 0.9f, 0.2f, 1f);
    }

        // Actualiza visualmente cuánto se llenó la barra.
    private void UpdateProgressBar()
    {
        if (progressFillRect == null) return;
        if (totalCraftTime <= 0f) return;

        float progress = 1f - (craftTimer / totalCraftTime);
        progress = Mathf.Clamp01(progress);

        float fullWidth = 100f; // mismo ancho que rootRT.sizeDelta.x
        progressFillRect.sizeDelta = new Vector2(fullWidth * progress, 0f);
    }

        // Elimina la barra de progreso cuando ya no se necesita.
    private void DestroyProgressBar()
    {
        if (progressBarRoot != null)
        {
            Destroy(progressBarRoot);
            progressBarRoot = null;
            progressFillImage = null;
            progressFillRect = null;
        }
    }
}