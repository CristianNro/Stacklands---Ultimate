
using UnityEngine;

// Helper para crear stacks fácilmente.
public static class CardStackFactory
{
    // Crea un stack nuevo con dos cartas.
    public static CardStack CreateStack(CardView firstCard, CardView secondCard)
    {
        if (firstCard == null || secondCard == null) return null;

        RectTransform firstRT = firstCard.GetComponent<RectTransform>();

        // Creamos GameObject del stack
        GameObject stackGO = new GameObject("CardStack", typeof(RectTransform));
        RectTransform stackRT = stackGO.GetComponent<RectTransform>();

        // Lo metemos en el board/playarea
        stackRT.SetParent(BoardRoot.Instance.transform, false);

        // Copiamos TODA la geometría del RectTransform de la primera carta
        stackRT.anchorMin = firstRT.anchorMin;
        stackRT.anchorMax = firstRT.anchorMax;
        stackRT.pivot = firstRT.pivot;
        stackRT.sizeDelta = firstRT.sizeDelta;
        stackRT.anchoredPosition = firstRT.anchoredPosition;
        stackRT.localScale = Vector3.one;
        stackRT.localRotation = Quaternion.identity;

        CardStack stack = stackGO.AddComponent<CardStack>();

        // Metemos ambas cartas
        stack.AddCard(firstCard);
        stack.AddCard(secondCard);

        return stack;
    }

}