using UnityEngine;

public class CardInitializer : MonoBehaviour
{
    public CardInstance cardInstance;
    public UnitRuntime unitRuntime;
    public BuildingRuntime buildingRuntime;

    public void Initialize(CardData data)
    {
        cardInstance.Initialize(data);

        if (data is UnitCardData unitData)
        {
            unitRuntime.enabled = true;
            unitRuntime.Initialize(unitData);
        }
        else
        {
            unitRuntime.enabled = false;
        }

        if (data is BuildingCardData buildingData)
        {
            buildingRuntime.enabled = true;
            buildingRuntime.Initialize(buildingData);
        }
        else
        {
            buildingRuntime.enabled = false;
        }
    }
}
