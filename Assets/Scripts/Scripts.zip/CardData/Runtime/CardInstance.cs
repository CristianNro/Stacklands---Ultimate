using UnityEngine;

public class CardInstance : MonoBehaviour
{
    [Header("Definition")]
    public CardData data;

    [Header("Runtime State")]
    public bool isDragging;
    public bool isSelected;
    public bool isBusy;

    public int usesRemaining;

    [Header("Stack")]
    public CardStack currentStack;

    public void Initialize(CardData data) // Inicializa la instancia a partir del CardData (plantilla).
    {
        this.data = data;
        usesRemaining = data.maxUses;
    }

    public bool HasTag(string tag)
    {
        return data != null && data.tags.Contains(tag);
    }
    
    public bool HasLimitedUses() => usesRemaining > 0; // Verifica si esta carta tiene durabilidad limitada (no infinita).

    public bool ConsumeUseIfNeeded() // Consume 1 uso de esta carta (si aplica).
    {
        
        if (usesRemaining == 0) return false; // Si usesRemaining == 0, significa que es infinita (no tiene límite).

        usesRemaining--; // Restamos 1 uso.
        
        return usesRemaining <= 0; // Si llegó a 0 o menos, la carta se rompió.
    }
}