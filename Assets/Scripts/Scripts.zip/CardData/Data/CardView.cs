using UnityEngine;
using UnityEngine.UI;
using TMPro;  // TextMeshPro para texto avanzado en UI

// Este componente vincula los datos de la carta (CardData) con su representación visual en pantalla.
// Se encarga de actualizar los sprites e texto basado en los datos asignados.
public class CardView : MonoBehaviour
{
    [Header("Data")]  // Agrupa en el inspector

    // Referencia a los datos de la carta (la plantilla con nombre, sprites, etc.).
    public CardData data;

    [Header("UI Reference")]  // Agrupa en el inspector

    // Referencia al componente Image que muestra el icono/imagen central de la carta.
    [SerializeField] private Image cardImage;

    // Referencia al componente que muestra el nombre de la carta.
    [SerializeField] private string cardName;


    public void printAll()
    {
        Debug.Log(data.cardName + ", " + cardImage.sprite.name );
    }

    // OnValidate() se llama cada vez que cambias valores en el Inspector (sin presionar Play).
    // Es útil para previews: cambias el CardData asignado y VES al instante cómo se ve.
    private void OnValidate()
    {
        // Refrescamos la visual cada vez que cualquier valor cambia en el Inspector.
        Refresh(); 
    }

    // Actualiza todos los elementos visuales de la carta basado en los datos actuales (this.data).
    public void Refresh()
    {
        // Si no hay datos asignados (data == null), no podemos actualizar nada.
        if (data == null) return;

        // Si existe un elemento de texto, le asignamos el nombre de la carta.
        if (cardName != null)
            cardName = data.cardName;

        // Si existe la imagen de la carta, le asignamos la imagen.
        if (cardImage != null)
            cardImage.sprite = data.cardImage;
    }
}
