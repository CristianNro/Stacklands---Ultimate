using UnityEngine;
using UnityEngine.EventSystems;  // Necesario para manejar clicks del mouse

// Este componente vincula un BOTÓN de UI con la creación de cartas.
// Cuando el usuario hace click en el botón, spawnea una carta específica.
// Es diferente a CardSpawner: este es más específico (un botón crea UNA carta tipo).
// Implementa IPointerClickHandler para detectar clicks.
public class CardSpawnerButton : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] private GameObject cardPrefab;
    [SerializeField] private CardData cardToSpawn;
    [SerializeField] private Transform cardsParent;

    public void OnPointerClick(PointerEventData eventData)
    {
        GameObject go = Instantiate(cardPrefab, cardsParent);

        RectTransform rt = go.GetComponent<RectTransform>();

        // Normalizamos completamente el RectTransform
        rt.anchorMin = new Vector2(0.5f, 0.5f);
        rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.localScale = Vector3.one;
        rt.localRotation = Quaternion.identity;
        rt.anchoredPosition = Vector2.zero;

        CardView view = go.GetComponent<CardView>();
        CardInstance instance = go.GetComponent<CardInstance>();

        view.data = cardToSpawn;
        view.Refresh();

        instance.Initialize(cardToSpawn);
    }

}