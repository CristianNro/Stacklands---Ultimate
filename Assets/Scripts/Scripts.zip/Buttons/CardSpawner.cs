using UnityEngine;
using System.Collections;

// Este componente se encarga de instanciar cartas y asignarles su CardData.
// También puede spawnearlas con animación.
public class CardSpawner : MonoBehaviour
{
    // Prefab visual genérico de carta
    [SerializeField] private GameObject cardPrefab;

    // Contenedor donde viven las cartas (PlayArea / BoardRoot)
    [SerializeField] private Transform cardsParent;

    public static CardSpawner Instance { get; private set; }

    // Exponemos el contenedor para poder calcular posiciones desde otros scripts
    public Transform CardsParent => cardsParent;

    private void Awake()
    {
        Instance = this;
    }

    // Spawn normal, sin animación
    public GameObject Spawn(CardData data, Vector2 anchoredPosition)
    {
        // Creamos la carta
        GameObject go = Instantiate(cardPrefab, cardsParent);

        // La posicionamos
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchoredPosition = anchoredPosition;

        // Asignamos la data visual
        CardView view = go.GetComponent<CardView>();
        view.data = data;
        view.Refresh();

        // Inicializamos la instancia (usos/durabilidad)
        CardInstance instance = go.GetComponent<CardInstance>();
        if (instance != null)
            instance.Initialize(data);

        return go;
    }

    // Spawn con animación: aparece en startPos y se mueve hasta endPos
    public GameObject SpawnAnimated(CardData data, Vector2 startPos, float duration = 0.35f)
    {
        Vector2 endPos = startPos + new Vector2(120f, 160f);
    
        // Spawneamos la carta en la posición inicial (donde aparecerá el "destello")
        GameObject go = Spawn(data, startPos);

        StartCoroutine(AnimateMove(go.GetComponent<RectTransform>(), startPos, endPos, duration));

        return go;
    }

    // Coroutine para mover suavemente la carta
    private IEnumerator AnimateMove(RectTransform rt, Vector2 startPos, Vector2 endPos, float duration)
    {
        float time = 0f;

        // Altura del salto
        float jumpHeight = 180f;

        while (time < duration)
        {
            time += Time.deltaTime;

            // t va de 0 a 1
            float t = time / duration;

            // Movimiento base lineal entre inicio y fin
            Vector2 pos = Vector2.Lerp(startPos, endPos, t);

            // Curva parabólica:
            // 4 * t * (1 - t) vale:
            // - 0 al inicio
            // - 1 en el medio
            // - 0 al final
            float arc = 4f * t * (1f - t);

            // Le sumamos altura al eje Y para que haga el "salto"
            pos.y += arc * jumpHeight;

            rt.anchoredPosition = pos;

            yield return null;
        }

        rt.anchoredPosition = endPos;
    }
}