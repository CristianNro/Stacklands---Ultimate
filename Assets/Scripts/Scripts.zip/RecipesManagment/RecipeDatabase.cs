using UnityEngine;
using System.Collections.Generic;  // Necesario para List<T>

// Este componente es un GESTOR de recetas.
// Vive en la escena (por ejemplo en Board o PlayArea) como un singleton.
// Su responsabilidad:
// - Guardar TODAS las recetas del juego.
// - Buscar si existe una receta válida para un conjunto de cartas dado.
public class RecipeDatabase : MonoBehaviour
{
    // LISTA MAESTRA de todas las recetas del juego.
    // Arrastrás aquí cada RecipeData que crees desde el inspector.
    // Puedes tener 5, 10, 50 recetas: todas van acá.
    [SerializeField] private RecipeData[] recipes;

    // Singleton: permite que otros scripts accedan fácilmente a RecipeDatabase.Instance
    // sin tener que buscar el GameObject manualmente.
    // Es útil para que CardDrag pueda preguntar "¿existe una receta con estas cartas?".
    public static RecipeDatabase Instance { get; private set; }

    // Awake() se llama cuando la escena carga.
    private void Awake()
    {
        // Se asigna a sí mismo como la instancia única.
        Instance = this;
    }

    // Busca si existe una receta que corresponda al conjunto de cartas dado.
    // Devuelve la RecipeData que coincide, o null si no existe.
    public RecipeData FindRecipe(List<CardData> cards)
    {
        // Recorremos CADA receta en la base de datos.
        foreach (var recipe in recipes)
        {
            // Preguntamos a la receta: "¿tus ingredientes coinciden con estas cartas?".
            // Si la receta.Matches() devuelve true, encontramos una coincidencia.
            if (recipe.Matches(cards))
                return recipe;  // Retornamos esa receta.
        }

        // Si recorrimos todas y ninguna coincidió, devolvemos null.
        // CardDrag interpreta esto como "no hay receta, así que solo apila las cartas".
        return null;
    }
}