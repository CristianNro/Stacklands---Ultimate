using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "New Recipe", menuName = "Stacklands/Recipe")]
public class RecipeData : ScriptableObject
{
    // Ingredientes necesarios para esta receta
    public List<CardData> ingredients;

    // Resultado de la receta
    public CardData result;

    // Tiempo que tarda en completarse la receta, en segundos
    public float craftTime = 1f;

    // Verifica si una lista de cartas coincide con esta receta
    public bool Matches(List<CardData> cards)
    {
        // Si la cantidad no coincide, no puede ser esta receta
        if (cards.Count != ingredients.Count)
            return false;

        // Hacemos una copia para ir removiendo coincidencias
        List<CardData> remaining = new List<CardData>(cards);

        foreach (var ingredient in ingredients)
        {
            // Si falta un ingrediente, falla
            if (!remaining.Contains(ingredient))
                return false;

            // Lo removemos para evitar coincidencias duplicadas falsas
            remaining.Remove(ingredient);
        }

        return true;
    }
    // Override del método ToString() para debugging.
    // Cuando veas logs, verás algo como "Receta para Lodo: Agua, Tierra" en lugar de "RecipeData (clone)".
    public override string ToString()
    {
        return "Receta para " + result + ": " + string.Join(", ", ingredients);
    }
}